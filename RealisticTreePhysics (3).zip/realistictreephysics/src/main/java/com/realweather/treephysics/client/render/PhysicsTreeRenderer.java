package com.realweather.treephysics.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.realweather.treephysics.blockentity.PhysicsTreeBlockEntity;
import com.realweather.treephysics.physics.TreeBone;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * Walks the tree's bone hierarchy and draws each bone as a tapered
 * four-sided column, applying that bone's current physics rotation
 * before drawing its children - so a bending trunk correctly carries
 * every branch attached to it along with it.
 *
 * Vertices and normals are both submitted through the current
 * PoseStack.Pose (position matrix + normal matrix bundled together),
 * which is the vertex-building style used by Minecraft 1.21.x.
 */
public class PhysicsTreeRenderer implements BlockEntityRenderer<PhysicsTreeBlockEntity> {

    private static final ResourceLocation BARK_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("treephysics", "block/bark");
    private static final ResourceLocation LEAF_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("treephysics", "block/leaf_cluster");

    public PhysicsTreeRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public int getViewDistance() {
        return 64;
    }

    @Override
    public boolean shouldRenderOffScreen(PhysicsTreeBlockEntity be) {
        return false;
    }

    @Override
    public void render(PhysicsTreeBlockEntity be, float partialTick, PoseStack poseStack,
                        MultiBufferSource buffer, int packedLight, int packedOverlay) {
        TreeBone root = be.getOrBuildSkeleton().root;
        poseStack.pushPose();
        poseStack.translate(0.5, 0, 0.5); // center the trunk base on the block
        drawBone(root, poseStack, buffer, packedLight, true);
        poseStack.popPose();
    }

    private void drawBone(TreeBone bone, PoseStack poseStack, MultiBufferSource buffer,
                           int packedLight, boolean isTrunk) {
        poseStack.pushPose();
        poseStack.mulPose(Axis.XP.rotation(bone.restPitch + bone.bend));
        poseStack.mulPose(Axis.YP.rotation(bone.restYaw + bone.sway));

        VertexConsumer consumer = buffer.getBuffer(RenderType.entitySolid(isTrunk ? BARK_TEXTURE : LEAF_TEXTURE));
        drawTaperedColumn(poseStack, consumer, bone.baseRadius, bone.tipRadius, bone.length, packedLight);

        // Move to this bone's tip so children attach at the right spot.
        poseStack.translate(0, bone.length, 0);
        for (TreeBone child : bone.children) {
            drawBone(child, poseStack, buffer, packedLight, false);
        }
        if (bone.children.isEmpty() && !isTrunk) {
            drawLeafCluster(poseStack, buffer, packedLight);
        }

        poseStack.popPose();
    }

    /** Four tapered quads approximating a tapered cylinder - cheap, no extra mesh data needed. */
    private void drawTaperedColumn(PoseStack poseStack, VertexConsumer consumer,
                                    float baseRadius, float tipRadius, float length, int light) {
        PoseStack.Pose pose = poseStack.last();
        float[][] corners = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
        for (int i = 0; i < 4; i++) {
            float[] a = corners[i];
            float[] b = corners[(i + 1) % 4];
            quad(consumer, pose,
                    a[0] * baseRadius, 0, a[1] * baseRadius,
                    b[0] * baseRadius, 0, b[1] * baseRadius,
                    b[0] * tipRadius, length, b[1] * tipRadius,
                    a[0] * tipRadius, length, a[1] * tipRadius,
                    light);
        }
    }

    private void drawLeafCluster(PoseStack poseStack, MultiBufferSource buffer, int light) {
        VertexConsumer consumer = buffer.getBuffer(RenderType.entitySolid(LEAF_TEXTURE));
        PoseStack.Pose pose = poseStack.last();
        float s = 0.4f;
        quad(consumer, pose, -s, -s, 0, s, -s, 0, s, s, 0, -s, s, 0, light);
        quad(consumer, pose, 0, -s, -s, 0, -s, s, 0, s, s, 0, s, -s, light);
    }

    private void quad(VertexConsumer c, PoseStack.Pose pose,
                       float x1, float y1, float z1, float x2, float y2, float z2,
                       float x3, float y3, float z3, float x4, float y4, float z4, int light) {
        vertex(c, pose, x1, y1, z1, 0, 0, light);
        vertex(c, pose, x2, y2, z2, 1, 0, light);
        vertex(c, pose, x3, y3, z3, 1, 1, light);
        vertex(c, pose, x4, y4, z4, 0, 1, light);
    }

    private void vertex(VertexConsumer c, PoseStack.Pose pose,
                         float x, float y, float z, float u, float v, int light) {
        c.addVertex(pose, x, y, z)
                .setColor(255, 255, 255, 255)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(light)
                .setNormal(pose, 0, 1, 0);
    }
}
