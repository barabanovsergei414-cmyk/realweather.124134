package com.realweather.treephysics.registry;

import com.realweather.treephysics.TreePhysicsMod;
import com.realweather.treephysics.blockentity.PhysicsTreeBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, TreePhysicsMod.MODID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PhysicsTreeBlockEntity>> PHYSICS_TREE =
            BLOCK_ENTITIES.register("physics_tree", () -> BlockEntityType.Builder.of(
                    PhysicsTreeBlockEntity::new, ModBlocks.PHYSICS_OAK.get()
            ).build(null));
}
