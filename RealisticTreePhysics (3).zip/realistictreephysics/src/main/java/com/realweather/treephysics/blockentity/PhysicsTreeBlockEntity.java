package com.realweather.treephysics.blockentity;

import com.realweather.treephysics.physics.TreeSkeleton;
import com.realweather.treephysics.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class PhysicsTreeBlockEntity extends BlockEntity {

    /** Deterministic per-tree seed so the generated shape survives reloads. */
    private long seed;
    /** Built lazily on the client the first time it's needed for rendering/physics. */
    private TreeSkeleton skeleton;

    public PhysicsTreeBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.PHYSICS_TREE.get(), pos, state);
        this.seed = pos.asLong();
    }

    public TreeSkeleton getOrBuildSkeleton() {
        if (skeleton == null) {
            skeleton = TreeSkeleton.generate(seed);
        }
        return skeleton;
    }

    /** Registered as the client ticker in PhysicsTreeBlock#getTicker. */
    public static void clientTick(Level level, BlockPos pos, BlockState state, PhysicsTreeBlockEntity be) {
        be.getOrBuildSkeleton().tickPhysics(level, pos, 1f / 20f);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putLong("Seed", seed);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (tag.contains("Seed")) {
            this.seed = tag.getLong("Seed");
        }
    }
}
