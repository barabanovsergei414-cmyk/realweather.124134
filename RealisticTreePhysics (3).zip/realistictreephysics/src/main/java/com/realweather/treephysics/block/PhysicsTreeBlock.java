package com.realweather.treephysics.block;

import com.mojang.serialization.MapCodec;
import com.realweather.treephysics.blockentity.PhysicsTreeBlockEntity;
import com.realweather.treephysics.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

/**
 * One placed block = the root of a procedurally generated tree whose
 * whole shape (trunk + every branch) is drawn and animated entirely by
 * {@link com.realweather.treephysics.client.render.PhysicsTreeRenderer}.
 * The vanilla block model itself is invisible on purpose.
 */
public class PhysicsTreeBlock extends BaseEntityBlock {

    public static final MapCodec<PhysicsTreeBlock> CODEC = simpleCodec(PhysicsTreeBlock::new);

    public PhysicsTreeBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PhysicsTreeBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        // Physics only needs to run where the tree is actually seen, so it's client-only.
        return level.isClientSide
                ? createTickerHelper(type, ModBlockEntities.PHYSICS_TREE.get(), PhysicsTreeBlockEntity::clientTick)
                : null;
    }

    @Override
    protected VoxelShape getOcclusionShape(BlockState state, BlockGetter level, BlockPos pos) {
        // A real tree isn't a 1x1x1 cube - don't let it occlude neighbours.
        return Shapes.empty();
    }
}
