package com.realweather.treephysics.physics;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

/**
 * Source of wind for every tree in the world.
 *
 * By default this generates its own ambient noise-based wind, so the mod
 * works completely standalone. If you later want RealWeather (or any
 * other weather mod) to drive it instead - e.g. storms creating much
 * stronger, more directional wind near a supercell - call
 * {@link #setExternalProvider} once from your client setup code and this
 * class will defer to it instead.
 */
public final class WindField {
    private WindField() {}

    public interface Provider {
        /** @return {strength 0..1, directionRadians} at this position/time. */
        float[] windAt(Level level, BlockPos pos, long gameTime);
    }

    private static volatile Provider external;

    public static void setExternalProvider(Provider provider) {
        external = provider;
    }

    public static float[] windAt(Level level, BlockPos pos, long gameTime) {
        Provider provider = external;
        if (provider != null) {
            return provider.windAt(level, pos, gameTime);
        }
        double t = gameTime / 200.0;
        double nx = SmoothNoise.sample(pos.getX() * 0.01 + t, pos.getZ() * 0.01, t);
        double ny = SmoothNoise.sample(pos.getX() * 0.01, pos.getZ() * 0.01 + t, t * 0.7);
        float direction = (float) (nx * Math.PI);
        float strength = (float) Math.max(0, 0.35 + ny * 0.3 + 0.15 * Math.sin(t * 0.37));
        return new float[]{Math.min(1f, strength), direction};
    }
}
